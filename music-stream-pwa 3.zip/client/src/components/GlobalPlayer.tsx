import { usePlayer } from "@/contexts/PlayerContext";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Heart } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect } from "react";

export function GlobalPlayer() {
  const { user } = useAuth();
  const { currentTrack, isFavorite, toggleFavorite: toggleFavoriteLocal } = usePlayer();
  const toggleFavoriteMutation = trpc.tracks.toggleFavorite.useMutation();

  const handleToggleFavorite = async () => {
    if (!currentTrack) return;
    
    if (!user) {
      toast.error("Please sign in to save favorites");
      return;
    }

    try {
      const result = await toggleFavoriteMutation.mutateAsync({
        sourceId: currentTrack.id,
        source: currentTrack.source,
        title: currentTrack.title,
        artist: currentTrack.artist,
        duration: currentTrack.duration,
        thumbnail: currentTrack.thumbnail,
      });
      
      toggleFavoriteLocal(currentTrack.id);
      toast.success(result.isFavorite ? "Added to favorites" : "Removed from favorites");
    } catch (error) {
      console.error('Favorite error:', error);
      toast.error("Failed to update favorites");
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (!currentTrack || !('mediaSession' in navigator)) return;

    navigator.mediaSession.metadata = new MediaMetadata({
      title: currentTrack.title,
      artist: currentTrack.artist,
      artwork: [
        { src: currentTrack.thumbnail, sizes: '512x512', type: 'image/jpeg' }
      ]
    });

    navigator.mediaSession.setActionHandler('play', () => {
      const iframe = document.querySelector('iframe');
      if (iframe) {
        iframe.contentWindow?.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
      }
    });

    navigator.mediaSession.setActionHandler('pause', () => {
      const iframe = document.querySelector('iframe');
      if (iframe) {
        iframe.contentWindow?.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
      }
    });
  }, [currentTrack]);

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-20 left-0 right-0 z-40 px-4 pb-4">
      <Card className="bg-zinc-900/95 backdrop-blur border-zinc-800 overflow-hidden">
        {/* Video Player - Hidden but playing */}
        <div className="w-0 h-0 overflow-hidden">
          <iframe
            key={currentTrack.id}
            src={`https://www.youtube.com/embed/${currentTrack.id}?autoplay=1&rel=0&modestbranding=1`}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title={currentTrack.title}
          />
        </div>

        {/* Mini Player UI */}
        <div className="p-3 flex items-center gap-3">
          <img
            src={currentTrack.thumbnail}
            alt={currentTrack.title}
            className="w-12 h-12 rounded object-cover"
          />
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-semibold truncate text-white">{currentTrack.title}</h4>
            <p className="text-xs text-zinc-400 truncate">{currentTrack.artist}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300">
                {currentTrack.source === 'youtube' ? 'YouTube' : 'SoundCloud'}
              </span>
              <span className="text-xs text-zinc-500">{formatTime(currentTrack.duration)}</span>
            </div>
          </div>
          <Button 
            size="icon" 
            variant="ghost" 
            className="shrink-0"
            onClick={handleToggleFavorite}
          >
            <Heart 
              className={`w-5 h-5 ${isFavorite(currentTrack.id) ? 'fill-red-500 text-red-500' : 'text-white'}`} 
            />
          </Button>
        </div>
      </Card>
    </div>
  );
}
