import { Innertube } from 'youtubei.js';
import SCDL from 'soundcloud-downloader';

let youtube: Innertube | null = null;

/**
 * Get or create YouTube client instance
 */
async function getYouTubeClient() {
  if (!youtube) {
    youtube = await Innertube.create();
  }
  return youtube;
}

/**
 * Search YouTube for music tracks
 */
export async function searchYouTube(query: string, limit: number = 10) {
  try {
    const yt = await getYouTubeClient();
    const search = await yt.search(query, { type: 'video' });
    
    const results = search.videos.slice(0, limit).map((video: any) => {
      // Handle both string and object title formats
      const title = typeof video.title === 'string' ? video.title : (video.title?.text || video.title?.toString() || 'Unknown Title');
      const artist = video.author?.name || video.channel?.name || 'Unknown Artist';
      const duration = video.duration?.seconds || 0;
      const thumbnail = video.thumbnails?.[0]?.url || video.best_thumbnail?.url || '';
      
      return {
        id: video.id,
        title,
        artist,
        duration,
        thumbnail,
        source: 'youtube' as const,
      };
    });

    return results;
  } catch (error) {
    console.error('YouTube search error:', error);
    return []; // Return empty array instead of throwing
  }
}

/**
 * Get YouTube video stream URL
 */
export async function getYouTubeStreamUrl(videoId: string) {
  try {
    const yt = await getYouTubeClient();
    const info = await yt.getInfo(videoId);
    
    // Get audio-only format with best quality
    const format = info.chooseFormat({ 
      type: 'audio',
      quality: 'best'
    });

    let url: string;
    
    // Try to get URL directly or decipher if needed
    if (format.url) {
      url = format.url;
    } else if (format.decipher) {
      url = await format.decipher(yt.session.player);
    } else {
      throw new Error('Unable to get stream URL');
    }
    
    return {
      url: url,
      title: info.basic_info.title || '',
      artist: info.basic_info.author || '',
      duration: info.basic_info.duration || 0,
      thumbnail: info.basic_info.thumbnail?.[0]?.url || '',
    };
  } catch (error) {
    console.error('YouTube stream error:', error);
    throw new Error('Failed to get YouTube stream');
  }
}

/**
 * Search SoundCloud for music tracks
 */
export async function searchSoundCloud(query: string, limit: number = 10) {
  try {
    // SoundCloud search using the correct API
    const searchUrl = `https://api-v2.soundcloud.com/search/tracks?q=${encodeURIComponent(query)}&limit=${limit}`;
    const response = await fetch(searchUrl);
    
    if (!response.ok) {
      return [];
    }

    const data = await response.json();
    
    if (!data || !data.collection) {
      return [];
    }

    return data.collection.map((track: any) => ({
      id: track.id?.toString() || '',
      title: track.title || 'Unknown Title',
      artist: track.user?.username || 'Unknown Artist',
      duration: Math.floor((track.duration || 0) / 1000), // Convert ms to seconds
      thumbnail: track.artwork_url || track.user?.avatar_url || '',
      source: 'soundcloud' as const,
    })).filter((track: any) => track.id); // Filter out invalid tracks
  } catch (error) {
    console.error('SoundCloud search error:', error);
    return []; // Return empty array instead of throwing
  }
}

/**
 * Get SoundCloud track stream URL
 */
export async function getSoundCloudStreamUrl(trackId: string) {
  try {
    const info = await SCDL.getInfo(`https://soundcloud.com/track/${trackId}`);
    
    if (!info) {
      throw new Error('Track not found');
    }

    // Get stream URL
    const stream = await SCDL.download(`https://soundcloud.com/track/${trackId}`);
    
    // For SoundCloud, we need to proxy the stream through our server
    // The stream object is a readable stream that we'll handle in the endpoint
    
    return {
      stream,
      title: info.title || '',
      artist: info.user?.username || '',
      duration: Math.floor((info.duration || 0) / 1000),
      thumbnail: info.artwork_url || info.user?.avatar_url || '',
    };
  } catch (error) {
    console.error('SoundCloud stream error:', error);
    throw new Error('Failed to get SoundCloud stream');
  }
}
